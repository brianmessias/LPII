package com.example.alunos.myapplication.model;

import android.os.Parcel;
import android.os.Parcelable;


/**
 * Created by alunos on 13/09/17.
 */

public class Pessoa implements Parcelable {
    private String nome;
    private String telefone;
    private int idade;

    public Pessoa(String nome, String telefone, int idade){
        this.nome = nome;
        this.telefone = telefone;
        this.idade = idade;
    }

    public String getNome(){
        return nome;
    }
    public void setNome(String nome){
        this.nome = nome;
    }
    public String getTelefone(){
        return telefone;
    }
    public void setTelefone(String telefone){
        this.telefone = telefone;
    }
    public int getIdade(){
        return idade;
    }
    public void setIdade(int idade){
        this.idade = idade;
    }

    public Pessoa(Parcel in){
        nome = in.readString();
        telefone = in.readString();
        idade = in.readInt();
    }
    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        // Serializa os campos da sua classe,
        // lembrando que essa ordem e importante no construtor
        dest.writeString(nome);
        dest.writeString(telefone);
        dest.writeInt(idade);
    }

    public static final Parcelable.Creator CREATOR = new Parcelable.Creator() {
        public Pessoa createFromParcel(Parcel in) {
            return new Pessoa(in);
        }

        public Pessoa[] newArray(int size) {
            return new Pessoa[size];
        }
    };

}
