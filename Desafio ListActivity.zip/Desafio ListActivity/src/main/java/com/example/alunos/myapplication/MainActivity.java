package com.example.alunos.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.alunos.myapplication.model.Pessoa;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {

    public ArrayList<Pessoa> lista = new ArrayList<Pessoa>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void showList(View v){
        Intent it = new Intent(this, mostraListaDinamica.class);
        it.putParcelableArrayListExtra("pessoas",lista);
        startActivity(it);
    }

    public void salvar(View v){

        TextView textNome = (TextView) v.findViewById(R.id.textNome);
        String nome = textNome.getText().toString();

        TextView textTelefone = (TextView) v.findViewById(R.id.textTelefone);
        String tel = textTelefone.getText().toString();

        TextView textIdade = (TextView) v.findViewById(R.id.textIdade);
        int idade = Integer.parseInt(String.valueOf(textIdade));

        lista.add(new Pessoa(nome,tel,idade));

    }

}
